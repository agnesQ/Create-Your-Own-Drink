<?php
    chdir(dirname(__FILE__));
?>
