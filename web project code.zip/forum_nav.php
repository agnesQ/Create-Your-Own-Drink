<h1>My forum</h1>
<div id="wrapper">
<div id="menu">
<a class="item" href="/create_your_own_drink/displayforum.php">Forum home</a> -
<a class="item" href="/create_your_own_drink/create_topic.php">Create a topic</a>
<br/>